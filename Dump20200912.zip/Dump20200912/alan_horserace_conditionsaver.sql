-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: alan_horserace
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `conditionsaver`
--

DROP TABLE IF EXISTS `conditionsaver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conditionsaver` (
  `entity_id` bigint NOT NULL AUTO_INCREMENT,
  `condition_name` varchar(100) NOT NULL,
  `condition_value` varchar(500) NOT NULL,
  PRIMARY KEY (`entity_id`),
  UNIQUE KEY `condition_name` (`condition_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conditionsaver`
--

LOCK TABLES `conditionsaver` WRITE;
/*!40000 ALTER TABLE `conditionsaver` DISABLE KEYS */;
INSERT INTO `conditionsaver` VALUES (1,'rank = 1 ; favorite = Yes ; raceType = Novices Hurdle ;','[{\"conditionParameter\":\"speedPoint\",\"conditionStatement\":\">\",\"conditionValue\":\"1\"}]'),(2,'rank=1','[{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"}]'),(3,'novice hurdle rank1 no.1','[{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"Novices Hurdle\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"}]'),(4,'rank = 1 ; favorite = Yes ; bfsp between 0 and 2 ; cardNumber = 2 70%','[{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"bfsp\",\"conditionStatement\":\"between\",\"conditionValue\":\"0 and 2\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"2\"}]'),(5,'favorite = Yes ; raceType = Novices ; cardNumber = 1 61/100','[{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"Novices\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"}]'),(6,'rank = 1 ; favorite = Yes ; bfsp between 0 and 2 ; raceType = Novices ; cardNumber = 5 ; 8/10','[{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"bfsp\",\"conditionStatement\":\"between\",\"conditionValue\":\"0 and 2\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"Novices\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"5\"}]'),(7,'distanceFurlongs between 12 and 100 ; rank = 1 ; favorite = Yes ; bfsp between 0 and 2','[{\"conditionParameter\":\"distanceFurlongs\",\"conditionStatement\":\"between\",\"conditionValue\":\"12 and 100\"},{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"bfsp\",\"conditionStatement\":\"between\",\"conditionValue\":\"0 and 2\"}]'),(8,'speedPoint = 0 ; favorite = Yes ; raceType = Novices ; cardNumber = 1 29/46','[{\"conditionParameter\":\"speedPoint\",\"conditionStatement\":\"=\",\"conditionValue\":\"0\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"Novices\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"}]'),(9,'officialGoingStandard,StandardSlowspeedPoint=0; favorite = Yes;raceType=Novices;cardNumber=1 15/20','[{\"conditionParameter\":\"officialGoing\",\"conditionStatement\":\"=\",\"conditionValue\":\"Standard,Standard To Slow\"},{\"conditionParameter\":\"speedPoint\",\"conditionStatement\":\"=\",\"conditionValue\":\"0\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"Novices\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"}]'),(10,'Furlongs12 and 100 ; rank = 1 ; favorite = Yes ; bfsp between 0 and 2 ; cardNumber = 2 ; 80%','[{\"conditionParameter\":\"distanceFurlongs\",\"conditionStatement\":\"between\",\"conditionValue\":\"12 and 100\"},{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"bfsp\",\"conditionStatement\":\"between\",\"conditionValue\":\"0 and 2\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"2\"}]'),(11,'rank = 1 ; favorite = Yes ; raceType = NH Flat 51%','[{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"NH Flat\"}]'),(12,'favorite = Yes ; raceType = Novices Hurdle ; cardNumber = 2 ; 68%','[{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"Novices Hurdle\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"2\"}]'),(13,'favorite = Yes ; raceType = Novices ; cardNumber = 4 61%','[{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"},{\"conditionParameter\":\"raceType\",\"conditionStatement\":\"=\",\"conditionValue\":\"Novices\"},{\"conditionParameter\":\"cardNumber\",\"conditionStatement\":\"=\",\"conditionValue\":\"4\"}]'),(14,'donay rank 1 fav 32%','[{\"conditionParameter\":\"course\",\"conditionStatement\":\"=\",\"conditionValue\":\"Doncaster\"},{\"conditionParameter\":\"rank\",\"conditionStatement\":\"=\",\"conditionValue\":\"1\"},{\"conditionParameter\":\"favorite\",\"conditionStatement\":\"=\",\"conditionValue\":\"Yes\"}]');
/*!40000 ALTER TABLE `conditionsaver` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-12 18:02:57
