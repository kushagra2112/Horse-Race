CREATE DATABASE  IF NOT EXISTS `alan_horserace` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `alan_horserace`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: alan_horserace
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `track_short_name`
--

DROP TABLE IF EXISTS `track_short_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `track_short_name` (
  `entity_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `track_name` varchar(100) NOT NULL,
  `track_short_name` varchar(4) NOT NULL,
  PRIMARY KEY (`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `track_short_name`
--

LOCK TABLES `track_short_name` WRITE;
/*!40000 ALTER TABLE `track_short_name` DISABLE KEYS */;
INSERT INTO `track_short_name` VALUES (1,'ayr','ayr'),(2,'cork','cork'),(3,'kempton','kemp'),(4,'sedgefield','sedg'),(5,'southwell','sout'),(6,'exeter','exet'),(7,'thurles','thur'),(8,'worcester','worc'),(9,'chepstow','chep'),(10,'downpatrick','down'),(11,'dundalk','dund'),(12,'newcastle','newc'),(13,'newmarket (rowley)','newm'),(14,'york','york'),(15,'fairyhouse','fair'),(16,'hexham','hexh'),(17,'limerick','lime'),(18,'wolverhampton','wolv'),(19,'curragh','curr'),(20,'gowran park','gowr'),(21,'musselburgh','muss'),(22,'yarmouth','yarm'),(23,'hereford','here'),(24,'huntingdon','hunt'),(25,'punchestown','punc'),(26,'bath','bath'),(27,'nottingham','nott'),(28,'wetherby','weth'),(29,'brighton','brig'),(30,'carlisle','carl'),(31,'chelmsford city','chel'),(32,'tramore','tram'),(33,'wincanton','winc'),(34,'fakenham','fake'),(35,'uttoxeter','utto'),(36,'ascot','asco'),(37,'catterick','catt'),(38,'ffos las','ffos'),(39,'leopardstown','leop'),(40,'market rasen','mark'),(41,'stratford','stra'),(42,'bangor','bang'),(43,'naas','naas'),(44,'plumpton','plum'),(45,'pontefract','pont'),(46,'windsor','wind'),(47,'fontwell','font'),(48,'navan','nava'),(49,'ludlow','ludl'),(50,'cheltenham','chel'),(51,'doncaster','donc'),(52,'newbury','newb'),(53,'galway','galw'),(54,'kelso','kels'),(55,'aintree','aint'),(56,'wexford','wexf'),(57,'clonmel','clon'),(58,'lingfield','ling'),(59,'warwick','warw'),(60,'taunton','taun'),(61,'redcar','redc'),(62,'tipperary','tipp'),(63,'leicester','leic'),(64,'down royal','down'),(65,'sandown','sand'),(66,'haydock','hayd'),(67,'epsom','epso'),(68,'newmarket (july)','newm'),(69,'chester','ches'),(70,'hamilton','hami'),(71,'newton abbot','newt'),(72,'salisbury','sali'),(73,'perth','pert'),(74,'sligo','slig'),(75,'killarney','kill'),(76,'ripon','ripo'),(77,'beverley','beve'),(78,'kilbeggan','kilb'),(79,'cartmel','cart'),(80,'ballinrobe','ball'),(81,'thirsk','thir'),(82,'bellewstown','bell'),(83,'goodwood','good'),(84,'roscommon','rosc'),(85,'listowel','list'),(86,'laytown','layt');
/*!40000 ALTER TABLE `track_short_name` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-24 21:33:06
